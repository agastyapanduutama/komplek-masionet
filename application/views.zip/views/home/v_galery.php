
    <section class="ftco-section bg-light">
    	<div class="container">
    		<div class="row">
    			


    			<div class="col-md-4 ftco-animate">
    				<div class="properties">
    					<a href="property-single.html" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(<?= base_url()?>assets/templates/images/custom/galeri/galeri1.jpeg);">
    						<div class="icon d-flex justify-content-center align-items-center">
    							<span class="icon-search2"></span>
    						</div>
    					</a>
    					<div class="text p-3">
    						
    						<div class="d-flex">
    							<div class="one">
		    						<h3><a href="property-single.html">Gambar Kegiatan</a></h3>
		    						<p>kegiatan</p>
	    						</div>
	    						<div class="two">
	    							
    							</div>
    						</div>
    						<p>Foto kegiatan</p>
    						<hr>
    						
    					</div>
    				</div>
    			</div>


    			<div class="col-md-4 ftco-animate">
    				<div class="properties">
    					<a href="property-single.html" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(<?= base_url()?>assets/templates/images/custom/galeri/galeri2.jpeg);">
    						<div class="icon d-flex justify-content-center align-items-center">
    							<span class="icon-search2"></span>
    						</div>
    					</a>
    					<div class="text p-3">
    						
    						<div class="d-flex">
    							<div class="one">
		    						<h3><a href="property-single.html">Gambar Kegiatan</a></h3>
		    						<p>kegiatan</p>
	    						</div>
	    						<div class="two">
	    							
    							</div>
    						</div>
    						<p>Foto kegiatan</p>
    						<hr>
    						
    					</div>
    				</div>
    			</div>
    			<div class="col-md-4 ftco-animate">
    				<div class="properties">
    					<a href="property-single.html" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(<?= base_url()?>assets/templates/images/custom/galeri/galeri3.jpeg);">
    						<div class="icon d-flex justify-content-center align-items-center">
    							<span class="icon-search2"></span>
    						</div>
    					</a>
    					<div class="text p-3">
    						
    						<div class="d-flex">
    							<div class="one">
		    						<h3><a href="property-single.html">Gambar Kegiatan</a></h3>
		    						<p>kegiatan</p>
	    						</div>
	    						<div class="two">
	    							 </span>
    							</div>
    						</div>
    						<p>Foto kegiatan</p>
    						<hr>
    						
    					</div>
    				</div>
    			</div>
    			<div class="col-md-4 ftco-animate">
    				<div class="properties">
    					<a href="property-single.html" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(<?= base_url()?>assets/templates/images/custom/galeri/galeri4.jpeg);">
    						<div class="icon d-flex justify-content-center align-items-center">
    							<span class="icon-search2"></span>
    						</div>
    					</a>
    					<div class="text p-3">
    						
    						<div class="d-flex">
    							<div class="one">
		    						<h3><a href="property-single.html">Gambar Kegiatan</a></h3>
		    						<p>kegiatan</p>
	    						</div>
	    						<div class="two">
	    							
    							</div>
    						</div>
    						<p>Foto kegiatan</p>
    						<hr>
    						
    					</div>
    				</div>
    			</div>
    			<div class="col-md-4 ftco-animate">
    				<div class="properties">
    					<a href="property-single.html" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(<?= base_url()?>assets/templates/images/custom/galeri/galeri5.jpeg);">
    						<div class="icon d-flex justify-content-center align-items-center">
    							<span class="icon-search2"></span>
    						</div>
    					</a>
    					<div class="text p-3">
    						
    						<div class="d-flex">
    							<div class="one">
		    						<h3><a href="property-single.html">Gambar Kegiatan</a></h3>
		    						<p>kegiatan</p>
	    						</div>
	    						<div class="two">
	    							
    							</div>
    						</div>
    						<p>Foto kegiatan</p>
    						<hr>
    						
    					</div>
    				</div>
    			</div>
    			<div class="col-md-4 ftco-animate">
    				<div class="properties">
    					<a href="property-single.html" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(<?= base_url()?>assets/templates/images/custom/galeri/galeri6.jpeg);">
    						<div class="icon d-flex justify-content-center align-items-center">
    							<span class="icon-search2"></span>
    						</div>
    					</a>
    					<div class="text p-3">
    						
    						<div class="d-flex">
    							<div class="one">
		    						<h3><a href="property-single.html">Gambar Kegiatan</a></h3>
		    						<p>kegiatan</p>
	    						</div>
	    						<div class="two">
	    							
    							</div>
    						</div>
    						<p>Foto kegiatan</p>
    						<hr>
    						
    					</div>
    				</div>
    			</div>
    			<div class="col-md-4 ftco-animate">
    				<div class="properties">
    					<a href="property-single.html" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(<?= base_url()?>assets/templates/images/custom/galeri/galeri7.jpeg);">
    						<div class="icon d-flex justify-content-center align-items-center">
    							<span class="icon-search2"></span>
    						</div>
    					</a>
    					<div class="text p-3">
    						
    						<div class="d-flex">
    							<div class="one">
		    						<h3><a href="property-single.html">Gambar Kegiatan</a></h3>
		    						<p>kegiatan</p>
	    						</div>
	    						<div class="two">
	    							 </span>
    							</div>
    						</div>
    						<p>Foto kegiatan</p>
    						<hr>
    						
    					</div>
    				</div>
    			</div>
    			<div class="col-md-4 ftco-animate">
    				<div class="properties">
    					<a href="property-single.html" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(<?= base_url()?>assets/templates/images/custom/galeri/galeri8.jpeg);">
    						<div class="icon d-flex justify-content-center align-items-center">
    							<span class="icon-search2"></span>
    						</div>
    					</a>
    					<div class="text p-3">
    						
    						<div class="d-flex">
    							<div class="one">
		    						<h3><a href="property-single.html">Gambar Kegiatan</a></h3>
		    						<p>kegiatan</p>
	    						</div>
	    						<div class="two">
	    							
    							</div>
    						</div>
    						<p>Foto kegiatan</p>
    						<hr>
    						
    					</div>
    				</div>
    			</div>
    			<div class="col-md-4 ftco-animate">
    				<div class="properties">
    					<a href="property-single.html" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(<?= base_url()?>assets/templates/images/custom/galeri/galeri9.jpeg);">
    						<div class="icon d-flex justify-content-center align-items-center">
    							<span class="icon-search2"></span>
    						</div>
    					</a>
    					<div class="text p-3">
    						
    						<div class="d-flex">
    							<div class="one">
		    						<h3><a href="property-single.html">Gambar Kegiatan</a></h3>
		    						<p>kegiatan</p>
	    						</div>
	    						<div class="two">
	    							
    							</div>
    						</div>
    						<p>Foto kegiatan</p>
    						<hr>
    						
    					</div>
    				</div>
    			</div>
    		</div>
    		
    	</div>
    </section>
		