  <section class="ftco-section ftc-no-pb">
			<div class="container">
				<div class="row no-gutters">
					<div class="col-md-5 p-md-5 img img-2 d-flex justify-content-center align-items-center" style="background-image: url(<?= base_url('assets/templates/')?>images/about.jpg);">
						<a href="https://vimeo.com/45830194" class="icon popup-vimeo d-flex justify-content-center align-items-center">
							<span class="icon-play"></span>
						</a>
					</div>
					<div class="col-md-7 wrap-about pb-md-5 ftco-animate">
	          <div class="heading-section heading-section-wo-line mb-5 pl-md-5">
	          	<div class="pl-md-5 ml-md-5">
		          	<span class="subheading">PT. CIPTA SARI PUSAKA JAYA</span>
		            <h2 class="mb-4">Apa itu Maisonet?</h2>
	            </div>
	          </div>
	          <div class="pl-md-5 ml-md-5 mb-5">
							<p>kami mempersembahkan product hunian dengan harga terjangkau di lokasi yang sangat strategis, memiliki konsep SMART VILLAGE yaitu RUMAH MAISONET PONDOK SABILULUNGAN PERMAI 2. Apa itu Rumah Maisonet? Rumah Maisonet adalah rumah tapak bertingkat rendah mengakomodasi luas kavling yang lebih kecil dari 60meter..luas minimal rumah maisonet berkisar 30 - 40 meter.  
							<br>Perbedaan mendasar antara tipologi rumah tapak tidak bertingkat dengan rumah tapak bertingkat ( Rumah Maisonet ) adalah kebutuhan ruang untuk sirkulasi vertikal/tangga sehingga tidak mengganggu ruang lainnya. 
							<br>
							<br>Kebutuhan ruang pada Rumah Maisonet meliputi ruang hunian dasar dan ruang sirkulasi vertikal. Konsep Rumah Maisonet ini sangat cocok untuk KAUM MILENIAL yang syarat dengan hidup yang  Modern, simple, nyaman dan terkelola hingga konsumen dapat  merasakan kenyamanan, keamanan dan ketenangan serasa tinggal di APARTMENT </p>
						</div>
					</div>
				</div>
			</div>
		</section>


		
  <section class="ftco-section ftc-no-pb">
			<div class="container">
				<div class="row no-gutters">
					
					<div class="col-md-7 wrap-about pb-md-5 ftco-animate">
			          <div class="heading-section heading-section-wo-line mb-5 pl-md-5">
			          	<div class="pl-md-5 ml-md-5">
				            <h2 class="mb-4">Aksebilitas</h2>
			            </div>
			          </div>
			           <div class="pl-md-5 ml-md-5 mb-5">
							<p>Aksebilitas rumah Maisonet
								<ul>
									<li>Dekat tempat Wisata Batu Pabeasan, gunung puntang, wisata ciwidey dll</li>
									<li>View Bukit dan pegunungan</li>
									<li>Bebas macet dan banjir</li>
									<li>30menit menuju Tol Bubat, Tol Soroja dan Tol moch.toha</li>
									<li>Udara segar</li>
									<li>Dekat dengan pembangunan UNPAD fak. Pertanian dan Peternakan</li>
									<li>30 menit menuju kantor pemerintah daerah Kabupaten Bandung </li>
									<li>Dan Lainnya</li>
								</ul>
							</p>
						</div>
					</div>
					<div class="col-md-5 p-md-5 img img-2 d-flex justify-content-center align-items-center" style="background-image: url(<?= base_url('assets/templates/')?>images/about.jpg);">
						<a href="https://vimeo.com/45830194" class="icon popup-vimeo d-flex justify-content-center align-items-center">
							<span class="icon-play"></span>
						</a>
					</div>

				</div>
			</div>
		</section>


  <section class="ftco-section ftc-no-pb">
			<div class="container">
				<div class="row no-gutters">
					
					<div class="col-md-5 p-md-5 img img-2 d-flex justify-content-center align-items-center" style="background-image: url(<?= base_url('assets/templates/')?>images/about.jpg);">
						<a href="https://vimeo.com/45830194" class="icon popup-vimeo d-flex justify-content-center align-items-center">
							<span class="icon-play"></span>
						</a>
					</div>

					<div class="col-md-7 wrap-about pb-md-5 ftco-animate">
			          <div class="heading-section heading-section-wo-line mb-5 pl-md-5">
			          	<div class="pl-md-5 ml-md-5">
				            <h2 class="mb-4">Spesifikasi</h2>
			            </div>
			          </div>
			           <div class="pl-md-5 ml-md-5 mb-5">
							<p>Spesifikasi rumah Maisonet
								<ul>
									<li>Pondasi plat setempat beton bertulang</li>
									<li>Kontruksi beton bertulang</li>
									<li>Dinding bata ringan</li>
									<li>Kusen almunium</li>
									<li>Penutup atap genting metal pasir</li>
									<li>Rangka atap baja ringan</li>
									<li>Plafon holo dan gypsum</li>
									<li>Lantai keramik 60x60</li>
									<li>Lantai kamar mandi keramik 20x20</li>
									<li>Dinding kamar mandi keramik 20x25</li>
									<li>Pintu panel almunium</li>
									<li>Pintu dalam multi</li>
									<li>Sanitair closet duduk</li>
									<li>air summersible</li>
								</ul>
							</p>
						</div>
					</div>
					

				</div>
			</div>
		</section>


